#pragma once

#include <QObject>
#include <QSet>
#include <QTimer>
#include <QDateTime>
#include <QMap>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QGuiApplication>
#include <QSocketNotifier>
#include <QList>

#include <QVector>
#include <QRect>

class QQuickWindow;

class Backend : public QObject {
    Q_OBJECT

    Q_PROPERTY(int kpm READ kpm NOTIFY statsChanged)
    Q_PROPERTY(QString topKey READ topKey NOTIFY statsChanged)
    Q_PROPERTY(int totalKeys READ totalKeys NOTIFY statsChanged)
    Q_PROPERTY(QString lastKey READ lastKey NOTIFY lastKeyChanged)
    Q_PROPERTY(QStringList recentKeys READ recentKeys NOTIFY recentKeysChanged)
    Q_PROPERTY(int mouseX READ mouseX NOTIFY mouseMoved)
    Q_PROPERTY(int mouseY READ mouseY NOTIFY mouseMoved)
    Q_PROPERTY(bool leftButton READ leftButton NOTIFY mouseButtonChanged)
    Q_PROPERTY(bool rightButton READ rightButton NOTIFY mouseButtonChanged)
    Q_PROPERTY(bool middleButton READ middleButton NOTIFY mouseButtonChanged)
    Q_PROPERTY(int totalClicks READ totalClicks NOTIFY statsChanged)
    Q_PROPERTY(int cpm READ cpm NOTIFY statsChanged)
    Q_PROPERTY(bool scrolling READ scrolling NOTIFY scrollChanged)
    Q_PROPERTY(int scrollDirection READ scrollDirection NOTIFY scrollChanged)
    Q_PROPERTY(bool clickThrough READ clickThrough WRITE setClickThrough NOTIFY clickThroughChanged)
    Q_PROPERTY(bool alphaBackground READ alphaBackground WRITE setAlphaBackground NOTIFY alphaBackgroundChanged)

public:
    explicit Backend(QObject *parent = nullptr);
    ~Backend();

    int kpm() const { return m_kpm; }
    QString topKey() const;
    int totalKeys() const { return m_totalKeys; }
    QString lastKey() const { return m_lastKey; }
    QStringList recentKeys() const { return m_recentKeys; }
    int mouseX() const { return m_mouseX; }
    int mouseY() const { return m_mouseY; }
    bool leftButton() const { return m_leftButton; }
    bool rightButton() const { return m_rightButton; }
    bool middleButton() const { return m_middleButton; }
    int totalClicks() const { return m_totalClicks; }
    int cpm() const { return m_cpm; }
    bool scrolling() const { return m_scrolling; }
    int scrollDirection() const { return m_scrollDirection; }

    Q_INVOKABLE void registerKey(const QString &key);
    Q_INVOKABLE bool isKeyPressed(const QString &key) const;
    Q_INVOKABLE void setupX11Overlay(QObject *win);
    Q_INVOKABLE void setupPopupOverlay(QObject *win);
    Q_INVOKABLE int addExcludeRect(int x, int y, int w, int h);
    Q_INVOKABLE void removeExcludeRect(int id);
    Q_INVOKABLE void clearExcludeRects();

    bool clickThrough() const { return m_clickThrough; }
    void setClickThrough(bool enable);

    bool alphaBackground() const { return m_alphaBackground; }
    void setAlphaBackground(bool enable);

    bool eventFilter(QObject *obj, QEvent *event) override;

signals:
    void keyChanged(const QString &key, bool pressed);
    void statsChanged();
    void lastKeyChanged();
    void mouseMoved();
    void mouseButtonChanged();
    void scrollChanged();
    void toggleOverlay();
    void recentKeysChanged();
    void clickThroughChanged();
    void alphaBackgroundChanged();

private:
    void processKey(const QString &key, bool pressed);
    void updateKpm();
    void updateCpm();
    QString keyEventToString(QKeyEvent *ke) const;
    QString normalizeKeyName(const QString &raw) const;
    void updateMouseButton(Qt::MouseButton button, bool pressed);

    void initX11GlobalCapture();
    void pollX11Events();
    void handleXI2Button(uint8_t detail, bool pressed);

    void initRecordCapture();
    void cleanupRecordCapture();
    void onRecordDataAvailable();

    void initEvdevCapture();
    void readEvdevEvents();
    void cleanupEvdevCapture();

    void initX11Overlay();
    void applyClickThrough(bool enable);
    void applyAlphaBackground(bool enable);

    int m_rectIdCounter = 0;
    QMap<int, QRect> m_excludeRects;

    QSet<QString> m_pressedKeys;
    QList<qint64> m_times;
    QList<qint64> m_clickTimes;
    int m_kpm = 0;
    int m_cpm = 0;
    int m_totalKeys = 0;
    int m_totalClicks = 0;
    QString m_lastKey;
    QStringList m_recentKeys;
    QMap<QString, int> m_keyCounts;

    int m_mouseX = 0;
    int m_mouseY = 0;
    bool m_leftButton = false;
    bool m_rightButton = false;
    bool m_middleButton = false;
    bool m_scrolling = false;
    int m_scrollDirection = 0;

    QTimer *m_statsTimer;
    QTimer *m_pollTimer;

    void *m_x11Display = nullptr;
    void *m_xcbConn = nullptr;
    int m_xiOpcode = 0;
    char m_prevKeyState[32] = {};
    QMap<int, QString> m_x11KeyNames;
    void initX11KeyNames();
    void initXCBXI2();
    void processXCBEvents();

    void *m_recordDataDisplay = nullptr;
    unsigned long m_recordContext = 0;
    QSocketNotifier *m_recordNotifier = nullptr;
    bool m_recordEnabled = false;

    QList<int> m_evdevDevices;
    QTimer *m_evdevTimer = nullptr;

    bool m_clickThrough = false;
    bool m_alphaBackground = true;
    unsigned long m_overlayWindow = 0;
    QQuickWindow *m_overlayQWindow = nullptr;
};
