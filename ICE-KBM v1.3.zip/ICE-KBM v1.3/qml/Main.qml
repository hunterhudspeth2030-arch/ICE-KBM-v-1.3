import QtQuick
import QtQuick.Window

Window {
    id: win
    visible: true
    flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
    color: backgroundVisible ? "#0a0a0a" : "transparent"
    width: 1350
    height: 750
    minimumWidth: 800
    minimumHeight: 500
    title: "Input Visualizer"

    property real overlayOpacity: 1.0
    property bool mouseVisible: true
    property bool settingsVisible: false
    property bool compactMode: false
    property bool backgroundVisible: true
    property bool clickThroughSaved: true
    property bool keySolidBackground: false

    onBackgroundVisibleChanged: {
        if (!backgroundVisible) {
            var s = win.screen
            if (s) {
                win.x = s.width - win.width - 10
                win.y = s.height - win.height - 50
            }
        }
    }

    onSettingsVisibleChanged: {
        if (settingsVisible) {
            clickThroughSaved = backend.clickThrough
            if (backend.clickThrough)
                backend.clickThrough = false
        } else {
            if (clickThroughSaved)
                backend.clickThrough = true
        }
    }

    MouseArea {
        id: dragHandle
        y: 0
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.rightMargin: 80
        height: 30
        visible: !settingsVisible
        cursorShape: Qt.OpenHandCursor
        propagateComposedEvents: true

        property int dragWinX: 0
        property int dragWinY: 0
        property int dragMouseX: 0
        property int dragMouseY: 0

        onPressed: function(mouse) {
            if (mouse.button === Qt.LeftButton) {
                dragWinX = win.x
                dragWinY = win.y
                dragMouseX = mouse.x
                dragMouseY = mouse.y
            }
        }
        onPositionChanged: function(mouse) {
            if (mouse.buttons & Qt.LeftButton) {
                win.x = dragWinX + (mouse.x - dragMouseX)
                win.y = dragWinY + (mouse.y - dragMouseY)
            }
        }
    }

    Item {
        anchors.fill: parent
        opacity: overlayOpacity

        Rectangle {
            id: titleBar
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            height: 30
            color: "#12122aff"
            visible: backgroundVisible

            property int rectId: 0

            Component.onCompleted: {
                if (visible)
                    rectId = backend.addExcludeRect(0, 0, width, height)
            }
            onWidthChanged: {
                if (visible && rectId > 0) {
                    backend.removeExcludeRect(rectId)
                    rectId = backend.addExcludeRect(0, 0, width, height)
                }
            }
            onVisibleChanged: {
                if (visible) {
                    if (rectId > 0)
                        backend.removeExcludeRect(rectId)
                    rectId = backend.addExcludeRect(0, 0, width, height)
                } else if (rectId > 0) {
                    backend.removeExcludeRect(rectId)
                    rectId = 0
                }
            }

            Row {
                anchors.left: parent.left
                anchors.leftMargin: 8
                anchors.verticalCenter: parent.verticalCenter
                spacing: 6

                Rectangle {
                    width: 140; height: 20; radius: 4
                    color: "#1a1a3aff"
                    border.color: "#3a3a6aff"

                    Text {
                        anchors.centerIn: parent
                        text: "INPUT VISUALIZER"
                        color: "#c0d0f0"
                        font.pixelSize: 9
                        font.family: "monospace"
                        font.bold: true
                        font.letterSpacing: 2
                    }
                }

                Row {
                    spacing: 4
                    Repeater {
                        model: backend.recentKeys
                        Rectangle {
                            width: 22; height: 20; radius: 4
                            color: "#00f5d430"
                            border.color: "#00f5d460"
                            Text {
                                anchors.centerIn: parent
                                text: modelData
                                color: "#c0d0f0"
                                font.pixelSize: 9
                                font.bold: true
                                font.family: "monospace"
                            }
                        }
                    }
                }
            }

            Row {
                anchors.right: parent.right
                anchors.rightMargin: 6
                anchors.verticalCenter: parent.verticalCenter
                spacing: 3

                TitleButton {
                    text: "\u25A1"
                    tooltip: "Compact"
                    onClicked: compactMode = !compactMode
                    highlight: compactMode
                    colorOn: "#7209b7"
                }
                TitleButton {
                    text: "M"
                    tooltip: "Mouse"
                    onClicked: mouseVisible = !mouseVisible
                    highlight: mouseVisible
                }
                TitleButton {
                    text: "BG"
                    tooltip: "Backdrop"
                    onClicked: backgroundVisible = !backgroundVisible
                    highlight: backgroundVisible
                    colorOn: "#ffd60a"
                }
                TitleButton {
                    text: "\u2699"
                    tooltip: "Settings"
                    onClicked: settingsVisible = !settingsVisible
                    highlight: settingsVisible
                }
                TitleButton {
                    text: "\u2014"
                    tooltip: "Minimize"
                    onClicked: win.hide()
                }
                TitleButton {
                    text: "\u2715"
                    tooltip: "Quit"
                    onClicked: Qt.quit()
                }
            }
        }

        Rectangle {
            id: settingsPanel
            anchors.top: titleBar.bottom
            anchors.topMargin: 4
            anchors.right: parent.right
            anchors.rightMargin: 6
            width: 230
            height: 520
            radius: 10
            color: "#0d0d1a"
            border.color: "#3a3a5a"
            border.width: 1
            z: 20
            visible: settingsVisible

            Flickable {
                anchors.fill: parent
                anchors.margins: 12
                contentHeight: column.height + 24
                clip: true

                Column {
                    id: column
                    width: parent.width
                    spacing: 10

                    Rectangle {
                        anchors.right: parent.right
                        width: 20; height: 20; radius: 4
                        color: "#3a1a1a"
                        border.color: "#6a3a3a"
                        Text {
                            anchors.centerIn: parent
                            text: "\u2715"
                            color: "#f06060"
                            font.pixelSize: 10
                        }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: settingsVisible = false
                        }
                    }

                    Text {
                        text: "OVERLAY OPACITY"
                        color: "#8b9bbd"
                        font.pixelSize: 9
                        font.family: "monospace"
                        font.letterSpacing: 2
                    }

                    Item {
                        width: parent.width
                        height: 20
                        Rectangle {
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width
                            height: 3
                            radius: 1.5
                            color: "#3a3a5a"
                        }
                        Rectangle {
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width * overlayOpacity
                            height: 3
                            radius: 1.5
                            color: "#00f5d4"
                        }
                        Rectangle {
                            x: parent.width * overlayOpacity - 6
                            y: (parent.height - 12) / 2
                            width: 12; height: 12; radius: 6
                            color: "#00f5d4"
                            MouseArea {
                                anchors.fill: parent
                                anchors.margins: -6
                                drag.target: parent
                                drag.axis: Drag.XAxis
                                drag.minimumX: -6
                                drag.maximumX: parent.parent.width - 6
                                onPositionChanged: {
                                    var val = (parent.x + 6) / parent.parent.width
                                    overlayOpacity = Math.max(0.05, Math.min(1.0, val))
                                }
                            }
                        }
                    }

                    SectionDivider {}

                    Text {
                        text: "TOGGLES"
                        color: "#8b9bbd"
                        font.pixelSize: 9
                        font.family: "monospace"
                        font.letterSpacing: 2
                    }

                    Grid {
                        columns: 2
                        columnSpacing: 4
                        rowSpacing: 4
                        SettingsButton { text: "MS"; label: "Mouse"; toggled: mouseVisible; onClicked: mouseVisible = !mouseVisible }
                        SettingsButton { text: "CP"; label: "Compact"; toggled: compactMode; onClicked: compactMode = !compactMode }
                        SettingsButton { text: "BG"; label: "Backdrop"; toggled: backgroundVisible; onClicked: backgroundVisible = !backgroundVisible }
                        SettingsButton { text: "CT"; label: "ClickThru"; toggled: backend.clickThrough; onClicked: backend.clickThrough = !backend.clickThrough }
                        SettingsButton { text: "AB"; label: "AlphaBg"; toggled: backend.alphaBackground; onClicked: backend.alphaBackground = !backend.alphaBackground }
                        SettingsButton { text: "SK"; label: "SolidKeys"; toggled: keySolidBackground; onClicked: keySolidBackground = !keySolidBackground }
                    }
                    Text {
                        text: "Ctrl+Shift+C toggles Click-Thru"
                        color: "#7a8aaa"
                        font.pixelSize: 7
                        font.family: "monospace"
                    }

                    SectionDivider {}

                    Text {
                        text: "COLOR MODE"
                        color: "#8b9bbd"
                        font.pixelSize: 9
                        font.family: "monospace"
                        font.letterSpacing: 2
                    }

                    Row {
                        spacing: 4
                        ColorButton { text: "Df"; label: "Default"; active: keyboardComp.colorMode === "default"; onClicked: keyboardComp.colorMode = "default"; accent: "#00f5d4" }
                        ColorButton { text: "Ne"; label: "Neon"; active: keyboardComp.colorMode === "neon"; onClicked: keyboardComp.colorMode = "neon"; accent: "#ff00ff" }
                        ColorButton { text: "Mo"; label: "Mono"; active: keyboardComp.colorMode === "mono"; onClicked: keyboardComp.colorMode = "mono"; accent: "#aaaaaa" }
                        ColorButton { text: "Cl"; label: "Classic"; active: keyboardComp.colorMode === "classic"; onClicked: keyboardComp.colorMode = "classic"; accent: "#4488ff" }
                        ColorButton { text: "Fi"; label: "Fire"; active: keyboardComp.colorMode === "fire"; onClicked: keyboardComp.colorMode = "fire"; accent: "#ff4444" }
                    }

                    SectionDivider {}

                    Text {
                        text: "PRESETS"
                        color: "#8b9bbd"
                        font.pixelSize: 9
                        font.family: "monospace"
                        font.letterSpacing: 2
                    }

                    Row {
                        spacing: 4
                        SettingsButton { text: "FL"; label: "Full"; toggled: keyboardComp.preset === "full"; onClicked: keyboardComp.preset = "full" }
                        SettingsButton { text: "FP"; label: "FPS"; toggled: keyboardComp.preset === "fps"; onClicked: keyboardComp.preset = "fps" }
                        SettingsButton { text: "WD"; label: "WASD"; toggled: keyboardComp.preset === "wasd"; onClicked: keyboardComp.preset = "wasd" }
                        SettingsButton { text: "MB"; label: "MOBA"; toggled: keyboardComp.preset === "moba"; onClicked: keyboardComp.preset = "moba" }
                    }

                    SectionDivider {}

                    Item {
                        width: parent.width
                        height: 36
                        SettingsButton {
                            anchors.left: parent.left
                            text: "\u2197"; label: "Pop Out"
                            width: 70
                            toggled: false
                            onClicked: popOutOverlay()
                        }
                        SettingsButton {
                            anchors.right: parent.right
                            text: "\u2715"; label: "Quit"
                            width: 70
                            toggled: false
                            onClicked: Qt.quit()
                        }
                    }

                    Text {
                        text: "Ctrl+Shift+V \u2194 Show/Hide"
                        color: "#8b9bbd40"
                        font.pixelSize: 7
                        font.family: "monospace"
                    }
                }
            }
        }

        Rectangle {
            id: quitFloating
            anchors.top: parent.top
            anchors.topMargin: 4
            anchors.right: settingsFloating.left
            anchors.rightMargin: 4
            width: 30
            height: 30
            radius: 15
            color: "#3a1a1ae0"
            border.color: "#6a3a3aa0"
            visible: !settingsVisible && !backgroundVisible

            property int rectId: 0

            Text {
                anchors.centerIn: parent
                text: "\u2715"
                color: "#f06060"
                font.pixelSize: 14
            }

            MouseArea {
                anchors.fill: parent
                onClicked: Qt.quit()
            }

            onVisibleChanged: {
                if (visible)
                    rectId = backend.addExcludeRect(x, y, width, height)
                else if (rectId > 0) {
                    backend.removeExcludeRect(rectId)
                    rectId = 0
                }
            }
            onXChanged: { if (visible && rectId > 0) { backend.removeExcludeRect(rectId); rectId = backend.addExcludeRect(x, y, width, height) } }
            onYChanged: { if (visible && rectId > 0) { backend.removeExcludeRect(rectId); rectId = backend.addExcludeRect(x, y, width, height) } }
        }

        Rectangle {
            id: settingsFloating
            anchors.top: parent.top
            anchors.topMargin: 4
            anchors.right: parent.right
            anchors.rightMargin: 6
            width: 30
            height: 30
            radius: 15
            color: "#1a1a3ae0"
            border.color: "#3a3a6aa0"
            visible: !settingsVisible && !backgroundVisible

            property int rectId: 0

            Text {
                anchors.centerIn: parent
                text: "\u2699"
                color: "#c0d0f0"
                font.pixelSize: 16
            }

            MouseArea {
                anchors.fill: parent
                onClicked: settingsVisible = true
            }

            onVisibleChanged: {
                if (visible)
                    rectId = backend.addExcludeRect(x, y, width, height)
                else if (rectId > 0) {
                    backend.removeExcludeRect(rectId)
                    rectId = 0
                }
            }
            onXChanged: { if (visible && rectId > 0) { backend.removeExcludeRect(rectId); rectId = backend.addExcludeRect(x, y, width, height) } }
            onYChanged: { if (visible && rectId > 0) { backend.removeExcludeRect(rectId); rectId = backend.addExcludeRect(x, y, width, height) } }
        }

        Item {
            id: overlayArea
            anchors.top: titleBar.bottom
            anchors.topMargin: 6
            anchors.left: parent.left
            anchors.leftMargin: 6
            anchors.right: parent.right
            anchors.rightMargin: 6
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 6
            clip: false

            onXChanged: { kbdWrap.updateDragRect(); mouseWrap.updateDragRect() }
            onYChanged: { kbdWrap.updateDragRect(); mouseWrap.updateDragRect() }

            Rectangle {
                id: kbdWrap
                x: 0; y: 0
                width: keyboardComp.width
                height: keyboardComp.height + 14
                color: "transparent"

                property int dragRectId: 0

                Component.onCompleted: updateDragRect()
                onXChanged: updateDragRect()
                onYChanged: updateDragRect()
                onWidthChanged: updateDragRect()

                function updateDragRect() {
                    if (dragRectId > 0)
                        backend.removeExcludeRect(dragRectId)
                    var ax = overlayArea.x + kbdWrap.x
                    var ay = overlayArea.y + kbdWrap.y
                    dragRectId = backend.addExcludeRect(ax, ay, kbdWrap.width, 14)
                }

                Rectangle {
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    height: 14
                    radius: 4
                    color: backgroundVisible ? "#1a1a3a80" : "#1a1a3a30"

                    Text {
                        anchors.centerIn: parent
                        text: "\u2261 KEYBOARD"
                        color: "#8b9bbd"
                        font.pixelSize: 8
                        font.family: "monospace"
                        font.letterSpacing: 2
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.OpenHandCursor
                        drag.target: kbdWrap
                        drag.axis: Drag.XAndYAxis
                    }
                }

                Keyboard {
                    id: keyboardComp
                    y: 14
                    backgroundGlass: backgroundVisible
                    keySolidBackground: win.keySolidBackground
                    width: 708
                    height: 280
                }
            }

            Rectangle {
                id: mouseWrap
                x: 718; y: 0
                width: 200
                height: 334
                color: "transparent"
                visible: mouseVisible

                property int dragRectId: 0

                Component.onCompleted: updateDragRect()
                onXChanged: updateDragRect()
                onYChanged: updateDragRect()
                onWidthChanged: updateDragRect()
                onVisibleChanged: {
                    if (visible) updateDragRect()
                    else if (dragRectId > 0) {
                        backend.removeExcludeRect(dragRectId)
                        dragRectId = 0
                    }
                }

                function updateDragRect() {
                    if (dragRectId > 0)
                        backend.removeExcludeRect(dragRectId)
                    var ax = overlayArea.x + mouseWrap.x
                    var ay = overlayArea.y + mouseWrap.y
                    dragRectId = backend.addExcludeRect(ax, ay, mouseWrap.width, 14)
                }

                Rectangle {
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    height: 14
                    radius: 4
                    color: backgroundVisible ? "#1a1a3a80" : "#1a1a3a30"

                    Text {
                        anchors.centerIn: parent
                        text: "\u2261 MOUSE"
                        color: "#8b9bbd"
                        font.pixelSize: 8
                        font.family: "monospace"
                        font.letterSpacing: 2
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.OpenHandCursor
                        drag.target: mouseWrap
                        drag.axis: Drag.XAndYAxis
                    }
                }

                Mouse {
                    id: mouseComp
                    y: 14
                    backgroundGlass: backgroundVisible
                    height: 320
                }
            }


        }
    }

    property var popOutWindow: null

    function popOutOverlay() {
        if (popOutWindow) {
            popOutWindow.show()
            popOutWindow.raise()
            return
        }
        var comp = Qt.createComponent("PopOut.qml")
        if (comp.status === Component.Ready) {
            popOutWindow = comp.createObject()
            popOutWindow.closing.connect(function() { popOutWindow = null })
        } else if (comp.status === Component.Error) {
            console.log("Pop-out creation failed:", comp.errorString())
        }
    }

    Connections {
        target: backend
        function onToggleOverlay() {
            if (win.visibility === Window.Hidden)
                win.show()
            else
                win.hide()
        }
    }

    component TitleButton: Item {
        property string text
        property string tooltip
        property bool highlight
        property color colorOn: "#00f5d4"
        signal clicked()

        width: 24; height: 24

        Rectangle {
            anchors.fill: parent
            radius: 4
            color: highlight ? Qt.rgba(colorOn.r, colorOn.g, colorOn.b, 0.2) : "transparent"
            border.color: highlight ? Qt.rgba(colorOn.r, colorOn.g, colorOn.b, 0.6) : "transparent"
        }

        Text {
            anchors.centerIn: parent
            text: parent.text
            color: highlight ? parent.colorOn : "#c0d0f0"
            font.pixelSize: 11
        }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onClicked: parent.clicked()
        }
    }

    component SettingsButton: Item {
        property string text
        property string label
        property bool toggled
        signal clicked()

        readonly property color offBg: "#1a1a2e"
        readonly property color onBg: "#003d33"
        readonly property color offBorder: "#3a3a5a"
        readonly property color onBorder: "#00f5d4"
        readonly property color offText: "#c0d0f0"
        readonly property color onText: "#00f5d4"

        width: 54; height: 42

        Rectangle {
            anchors.fill: parent
            radius: 6
            color: toggled ? onBg : offBg
            border.color: toggled ? onBorder : offBorder

            Column {
                anchors.centerIn: parent
                spacing: 2
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: parent.parent.parent.text
                    color: toggled ? onText : offText
                    font.pixelSize: 12
                    font.bold: true
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: parent.parent.parent.label
                    color: "#8b9bbd"
                    font.pixelSize: 8
                }
            }
        }

        MouseArea {
            anchors.fill: parent
            onClicked: parent.clicked()
        }
    }

    component SectionDivider: Rectangle {
        width: parent.width
        height: 1
        color: "#2a2a4a"
    }

    component ColorButton: Item {
        property string text
        property string label
        property bool active
        property color accent
        signal clicked()

        width: 38; height: 36

        Rectangle {
            anchors.fill: parent
            radius: 5
            color: active ? Qt.rgba(accent.r, accent.g, accent.b, 0.3) : "#1a1a2e"
            border.color: active ? accent : "#3a3a5a"

            Column {
                anchors.centerIn: parent
                spacing: 1
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: parent.parent.parent.text
                    color: active ? accent : "#c0d0f0"
                    font.pixelSize: 10
                    font.bold: true
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: parent.parent.parent.label
                    color: "#8b9bbd"
                    font.pixelSize: 7
                }
            }
        }

        MouseArea {
            anchors.fill: parent
            onClicked: parent.clicked()
        }
    }
}
