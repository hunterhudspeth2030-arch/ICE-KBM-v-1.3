import QtQuick

Item {
    id: keyboardRoot

    property bool backgroundGlass: true
    property string preset: "full"
    property string colorMode: "default"
    property bool keySolidBackground: false

    property var theme: themes[colorMode] || themes["default"]
    property color themeNormalColor: theme.normal
    property string effectiveNormal: keySolidBackground ?
        Qt.rgba(themeNormalColor.r, themeNormalColor.g, themeNormalColor.b, 1.0) :
        theme.normal

    property var presets: {
        "full": [],
        "fps": ["Esc","1","2","3","4","5","Bksp","Tab",
                "Q","W","E","R","T",
                "Caps","A","S","D","F","G","Enter",
                "Shift","Z","X","C","V","B",
                "Ctrl","Win","Alt","Space"],
        "wasd": ["W","A","S","D","Space","Shift","Ctrl","Alt"],
        "moba": ["Esc","1","2","3","4","5","6","Bksp","Tab",
                 "Q","W","E","R",
                 "Caps","A","S","D","F","B",
                 "Shift","Z","X","C","V",
                 "Ctrl","Alt","Space"]
    }

    function inPreset(label) {
        if (preset === "full") return true
        var list = presets[preset]
        if (!list) return true
        return list.indexOf(label) >= 0
    }

    property var themes: {
        "default": {
            normal: "#1e1e3a80",
            border: "#3a3a6a",
            textNormal: "#e0e0ff",
            accentMap: {
                "#f72585": ["Esc","Bksp"],
                "#7209b7": ["Tab","\\"],
                "#4361ee": ["Caps","Enter"],
                "#ffd60a": ["Shift"],
                "#00f5d4": ["Ctrl","Win","Alt","Space","Menu"]
            },
            fallback: "#00f5d4"
        },
        "neon": {
            normal: "#1a0a2e80",
            border: "#5a2a8a",
            textNormal: "#ffffff",
            accentMap: {
                "#ff00ff": ["Esc","Bksp"],
                "#00ffff": ["Tab","\\"],
                "#00ff00": ["Caps","Enter"],
                "#ffff00": ["Shift"],
                "#ff6600": ["Ctrl","Win","Alt","Space","Menu"]
            },
            fallback: "#ff00ff"
        },
        "mono": {
            normal: "#2a2a2a80",
            border: "#4a4a4a",
            textNormal: "#dddddd",
            accentMap: {
                "#aaaaaa": ["Esc","Bksp"],
                "#888888": ["Tab","\\"],
                "#666666": ["Caps","Enter"],
                "#cccccc": ["Shift"],
                "#eeeeee": ["Ctrl","Win","Alt","Space","Menu"]
            },
            fallback: "#aaaaaa"
        },
        "classic": {
            normal: "#0a0a2e80",
            border: "#2a2a6a",
            textNormal: "#c0d0f0",
            accentMap: {
                "#4488ff": ["Esc","Bksp"],
                "#6644ff": ["Tab","\\"],
                "#8844ff": ["Caps","Enter"],
                "#ff4488": ["Shift"],
                "#44ff88": ["Ctrl","Win","Alt","Space","Menu"]
            },
            fallback: "#4488ff"
        },
        "fire": {
            normal: "#2e0a0a80",
            border: "#6a2a2a",
            textNormal: "#ffdddd",
            accentMap: {
                "#ff4444": ["Esc","Bksp"],
                "#ff8844": ["Tab","\\"],
                "#ffcc44": ["Caps","Enter"],
                "#44ff44": ["Shift"],
                "#ff6600": ["Ctrl","Win","Alt","Space","Menu"]
            },
            fallback: "#ff4444"
        }
    }

    function activeColorFor(label) {
        var map = theme.accentMap
        for (var c in map) {
            if (map[c].indexOf(label) >= 0)
                return c
        }
        return theme.fallback
    }

    property var rows: [
        [
            { l: "Esc", w: 40 }, { l: "`", w: 40 },
            { l: "1", w: 40 }, { l: "2", w: 40 }, { l: "3", w: 40 },
            { l: "4", w: 40 }, { l: "5", w: 40 },
            { l: "6", w: 40 }, { l: "7", w: 40 }, { l: "8", w: 40 },
            { l: "9", w: 40 }, { l: "0", w: 40 },
            { l: "-", w: 40 }, { l: "=", w: 40 }, { l: "Bksp", w: 72 }
        ], [
            { l: "Tab", w: 60 },
            { l: "Q", w: 40 }, { l: "W", w: 40 }, { l: "E", w: 40 },
            { l: "R", w: 40 }, { l: "T", w: 40 },
            { l: "Y", w: 40 }, { l: "U", w: 40 }, { l: "I", w: 40 },
            { l: "O", w: 40 }, { l: "P", w: 40 },
            { l: "[", w: 40 }, { l: "]", w: 40 }, { l: "\\", w: 52 }
        ], [
            { l: "Caps", w: 76 },
            { l: "A", w: 40 }, { l: "S", w: 40 }, { l: "D", w: 40 },
            { l: "F", w: 40 }, { l: "G", w: 40 },
            { l: "H", w: 40 }, { l: "J", w: 40 }, { l: "K", w: 40 },
            { l: "L", w: 40 }, { l: ";", w: 40 }, { l: "'", w: 40 },
            { l: "Enter", w: 78 }
        ], [
            { l: "Shift", w: 92 },
            { l: "Z", w: 40 }, { l: "X", w: 40 }, { l: "C", w: 40 },
            { l: "V", w: 40 }, { l: "B", w: 40 },
            { l: "N", w: 40 }, { l: "M", w: 40 },
            { l: ",", w: 40 }, { l: ".", w: 40 }, { l: "/", w: 40 },
            { l: "Shift", w: 92 }
        ], [
            { l: "Ctrl", w: 54 }, { l: "Win", w: 48 }, { l: "Alt", w: 48 },
            { l: "Space", w: 252, u: true },
            { l: "Alt", w: 48 }, { l: "Win", w: 48 }, { l: "Menu", w: 48 },
            { l: "Ctrl", w: 54 }
        ]
    ]

    Rectangle {
        anchors.fill: parent
        anchors.margins: 4
        radius: 14
        color: "#0d0d1a90"
        border.color: "#1a1a3a60"
        border.width: 1
        visible: backgroundGlass
    }

    Column {
        anchors.centerIn: parent
        spacing: 5
        padding: 6

        Repeater {
            model: rows.length
            delegate: Row {
                spacing: 4
                Repeater {
                    model: rows[index]
                    delegate: Key {
                        keyLabel: modelData.l
                        keyWidth: modelData.w
                        ultraWide: modelData.u || false
                        activeColor: keyboardRoot.activeColorFor(modelData.l)
                        normalColor: keyboardRoot.effectiveNormal
                        normalBorder: keyboardRoot.theme.border
                        textColorNormal: keyboardRoot.theme.textNormal
                        opacity: keyboardRoot.inPreset(modelData.l) ? 1.0 : 0.0
                        enabled: keyboardRoot.inPreset(modelData.l)
                        Behavior on opacity { NumberAnimation { duration: 200 } }
                    }
                }
            }
        }
    }
}
