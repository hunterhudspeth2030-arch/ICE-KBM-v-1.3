import QtQuick

Rectangle {
    id: root

    property string keyLabel
    property real keyWidth: 48
    property real keyHeight: 48
    property real keyRadius: 8
    property color normalColor: "#1e1e3a80"
    property color activeColor: "#00f5d4"
    property color normalBorder: "#3a3a6a"
    property color textColorNormal: "#e0e0ff"
    property color textColorActive: "#0a0a1a"

    property bool pressed: false
    property bool ultraWide: false

    width: keyWidth
    height: keyHeight
    radius: keyRadius
    color: pressed ? activeColor : normalColor
    border.color: pressed ? activeColor : normalBorder
    border.width: 1

    Behavior on color {
        ColorAnimation { duration: 80; easing.type: Easing.InOutQuad }
    }
    Behavior on border.color {
        ColorAnimation { duration: 80; easing.type: Easing.InOutQuad }
    }

    transform: Scale {
        id: scaleAnim
        origin.x: root.width / 2
        origin.y: root.height / 2
        xScale: pressed ? 0.92 : 1.0
        yScale: pressed ? 0.92 : 1.0

        Behavior on xScale {
            NumberAnimation { duration: 100; easing.type: Easing.OutBack }
        }
        Behavior on yScale {
            NumberAnimation { duration: 100; easing.type: Easing.OutBack }
        }
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: -4
        radius: parent.radius + 4
        color: "transparent"
        border.color: activeColor
        border.width: 2
        opacity: pressed ? 0.35 : 0
        visible: opacity > 0

        Behavior on opacity {
            NumberAnimation { duration: 100 }
        }
    }

    Text {
        id: labelText
        anchors.centerIn: parent
        text: root.keyLabel
        color: pressed ? textColorActive : textColorNormal
        font.pixelSize: ultraWide ? 12 : 13
        font.bold: true
        font.family: "monospace"
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight

        Behavior on color {
            ColorAnimation { duration: 80 }
        }
    }

    Connections {
        target: backend
        function onKeyChanged(key, pressed) {
            if (key === root.keyLabel)
                root.pressed = pressed;
        }
    }

    MouseArea {
        anchors.fill: parent
        onClicked: backend.registerKey(root.keyLabel)
    }
}
