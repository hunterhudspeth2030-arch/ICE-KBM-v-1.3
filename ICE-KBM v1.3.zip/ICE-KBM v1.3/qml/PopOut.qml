import QtQuick
import QtQuick.Window
import CatchyOS

Window {
    id: popWin
    visible: true
    width: 560
    height: 215
    color: "transparent"
    flags: Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
    title: "CatchyOS Overlay"

    property var rows: [
        ["`","1","2","3","4","5","6","7","8","9","0","-","=","Bksp"],
        ["Tab","Q","W","E","R","T","Y","U","I","O","P","[","]","\\"],
        ["Caps","A","S","D","F","G","H","J","K","L",";","'","Enter"],
        ["Shift","Z","X","C","V","B","N","M",",",".","/","Shift"],
        ["Ctrl","Win","Alt","Space","Alt","Win","Ctrl"]
    ]

    Rectangle {
        id: dragBar
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        height: 22
        radius: 4
        color: "#1a1a3a"
        z: 10

        Text {
            anchors.left: parent.left
            anchors.leftMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            text: "\u2261 POPOUT"
            color: "#8b9bbd"
            font.pixelSize: 9
            font.family: "monospace"
            font.letterSpacing: 2
        }

        Rectangle {
            anchors.right: parent.right
            anchors.rightMargin: 4
            anchors.verticalCenter: parent.verticalCenter
            width: 16; height: 16; radius: 3
            color: "#3a1a1a"
            border.color: "#6a3a3a"

            Text {
                anchors.centerIn: parent
                text: "\u2715"
                color: "#f06060"
                font.pixelSize: 8
            }

            MouseArea {
                anchors.fill: parent
                onClicked: popWin.close()
            }
        }

        MouseArea {
            anchors.fill: parent
            anchors.rightMargin: 24
            cursorShape: Qt.OpenHandCursor

            property int dx: 0
            property int dy: 0
            property int wx: 0
            property int wy: 0

            onPressed: function(mouse) {
                if (mouse.button === Qt.LeftButton) {
                    dx = mouse.x; dy = mouse.y
                    wx = popWin.x; wy = popWin.y
                }
            }
            onPositionChanged: function(mouse) {
                if (mouse.buttons & Qt.LeftButton) {
                    popWin.x = wx + mouse.x - dx
                    popWin.y = wy + mouse.y - dy
                }
            }
        }
    }

    Column {
        anchors.centerIn: parent
        anchors.verticalCenterOffset: 10
        spacing: 3
        padding: 4

        Repeater {
            model: rows.length
            delegate: Row {
                spacing: 3
                Repeater {
                    model: rows[index]
                    delegate: Key {
                        keyLabel: modelData
                        keyWidth: modelData === "Space" ? 140 :
                                  modelData === "Ctrl" || modelData === "Win" || modelData === "Alt" || modelData === "Menu" ? 42 :
                                  modelData === "Shift" || modelData === "Caps" ? 58 :
                                  modelData === "Bksp" || modelData === "Enter" ? 58 :
                                  modelData === "Tab" || modelData === "\\" ? 48 : 30
                        keyHeight: 30
                        keyRadius: 5
                        ultraWide: modelData === "Space"
                    }
                }
            }
        }
    }
}
