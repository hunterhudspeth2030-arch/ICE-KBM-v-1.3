import QtQuick

Item {
    id: mouseRoot
    width: 200
    height: 300

    property bool backgroundGlass: true

    Rectangle {
        anchors.fill: parent
        anchors.margins: 4
        radius: 14
        color: "#0d0d1a90"
        border.color: "#1a1a3a60"
        border.width: 1
        visible: backgroundGlass
    }

    Rectangle {
        id: mouseBody
        anchors.horizontalCenter: parent.horizontalCenter
        y: 36
        width: 160
        height: 240
        radius: 50
        color: "#141428e0"
        border.color: "#3a3a6a80"
        border.width: 1

        gradient: Gradient {
            GradientStop { position: 0.0; color: "#1a1a3ae0" }
            GradientStop { position: 0.5; color: "#141428e0" }
            GradientStop { position: 1.0; color: "#0d0d1ae0" }
        }

        Rectangle {
            anchors.left: parent.left
            anchors.leftMargin: 3
            anchors.top: parent.top
            anchors.topMargin: 3
            width: 75
            height: 80
            radius: 30
            color: backend.leftButton ? "#00f5d4" : "#1a1a3490"
            border.color: backend.leftButton ? "#00f5d4" : "#2d2d5440"
            border.width: backend.leftButton ? 2 : 1

            Behavior on color { ColorAnimation { duration: 60 } }
            Behavior on border.color { ColorAnimation { duration: 60 } }

            Rectangle {
                anchors.fill: parent
                anchors.margins: -6
                radius: parent.radius + 6
                color: "transparent"
                border.color: "#00f5d4"
                border.width: 2
                opacity: backend.leftButton ? 0.5 : 0
                visible: opacity > 0
                Behavior on opacity { NumberAnimation { duration: 80 } }
            }

            Text {
                anchors.centerIn: parent
                text: "L"
                color: backend.leftButton ? "#0a0a1a" : "#aabbd860"
                font.bold: true
                font.pixelSize: 20
                font.family: "monospace"
                Behavior on color { ColorAnimation { duration: 60 } }
            }
        }

        Rectangle {
            anchors.right: parent.right
            anchors.rightMargin: 3
            anchors.top: parent.top
            anchors.topMargin: 3
            width: 75
            height: 80
            radius: 30
            color: backend.rightButton ? "#f72585" : "#1a1a3490"
            border.color: backend.rightButton ? "#f72585" : "#2d2d5440"
            border.width: backend.rightButton ? 2 : 1

            Behavior on color { ColorAnimation { duration: 60 } }
            Behavior on border.color { ColorAnimation { duration: 60 } }

            Rectangle {
                anchors.fill: parent
                anchors.margins: -6
                radius: parent.radius + 6
                color: "transparent"
                border.color: "#f72585"
                border.width: 2
                opacity: backend.rightButton ? 0.5 : 0
                visible: opacity > 0
                Behavior on opacity { NumberAnimation { duration: 80 } }
            }

            Text {
                anchors.centerIn: parent
                text: "R"
                color: backend.rightButton ? "#0a0a1a" : "#aabbd860"
                font.bold: true
                font.pixelSize: 20
                font.family: "monospace"
                Behavior on color { ColorAnimation { duration: 60 } }
            }
        }

        Rectangle {
            id: scrollWheel
            anchors.horizontalCenter: parent.horizontalCenter
            y: 100
            width: 34
            height: 55
            radius: 17
            color: "#1a1a3490"
            border.color: backend.scrolling ? "#ffd60a" : "#2d2d5440"
            border.width: backend.scrolling ? 2 : 1

            Behavior on border.color { ColorAnimation { duration: 100 } }

            Rectangle {
                id: scrollThumb
                anchors.horizontalCenter: parent.horizontalCenter
                y: backend.scrolling ? (backend.scrollDirection > 0 ? 5 : 30) : 20
                width: 18
                height: 14
                radius: 7
                color: backend.scrolling ? "#ffd60a" : "#2d2d5480"

                Behavior on y { NumberAnimation { duration: 120; easing.type: Easing.OutQuad } }
                Behavior on color { ColorAnimation { duration: 100 } }
            }

            Rectangle {
                anchors.fill: parent
                anchors.margins: -5
                radius: parent.radius + 5
                color: "transparent"
                border.color: "#ffd60a"
                border.width: 2
                opacity: backend.scrolling ? 0.4 : 0
                visible: opacity > 0
                Behavior on opacity { NumberAnimation { duration: 100 } }
            }
        }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 168
            width: 46
            height: 46
            radius: 23
            color: backend.middleButton ? "#7209b7" : "#1a1a3490"
            border.color: backend.middleButton ? "#7209b7" : "#2d2d5440"
            border.width: backend.middleButton ? 2 : 1

            Behavior on color { ColorAnimation { duration: 60 } }
            Behavior on border.color { ColorAnimation { duration: 60 } }

            Rectangle {
                anchors.fill: parent
                anchors.margins: -5
                radius: parent.radius + 5
                color: "transparent"
                border.color: "#7209b7"
                border.width: 2
                opacity: backend.middleButton ? 0.5 : 0
                visible: opacity > 0
                Behavior on opacity { NumberAnimation { duration: 80 } }
            }

            Text {
                anchors.centerIn: parent
                text: "M"
                color: "#aabbd860"
                font.bold: true
                font.family: "monospace"
            }
        }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 18
            width: 16
            height: 4
            radius: 2
            color: "#2d2d5440"
        }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 10
            width: 8
            height: 30
            radius: 4
            color: "#1a1a3490"
            border.color: "#2d2d5440"
            border.width: 1
        }
    }

    Item {
        anchors.horizontalCenter: parent.horizontalCenter
        y: 10
        width: 100
        height: 16
        visible: backgroundGlass

        Row {
            anchors.centerIn: parent
            spacing: 10
            Rectangle {
                width: 8; height: 8; radius: 4
                color: backend.leftButton ? "#00f5d4" : "#2d2d5440"
                Behavior on color { ColorAnimation { duration: 100 } }
            }
            Rectangle {
                width: 8; height: 8; radius: 4
                color: backend.rightButton ? "#f72585" : "#2d2d5440"
                Behavior on color { ColorAnimation { duration: 100 } }
            }
            Rectangle {
                width: 8; height: 8; radius: 4
                color: backend.scrolling ? "#ffd60a" : "#2d2d5440"
                Behavior on color { ColorAnimation { duration: 100 } }
            }
        }
    }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: mouseBody.bottom
        anchors.topMargin: 8
        width: 170
        height: 26
        radius: 6
        color: "#0f0f2080"
        border.color: "#2d2d5440"
        visible: backgroundGlass

        Row {
            anchors.centerIn: parent
            spacing: 8
            Text {
                text: "X:" + backend.mouseX
                color: "#aabbd890"
                font.pixelSize: 10
                font.family: "monospace"
            }
            Text {
                text: "Y:" + backend.mouseY
                color: "#aabbd890"
                font.pixelSize: 10
                font.family: "monospace"
            }
        }
    }
}
