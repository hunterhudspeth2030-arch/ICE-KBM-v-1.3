#include "backend.h"
#include <QCursor>
#include <QKeySequence>
#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QQuickWindow>

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#include <errno.h>

#ifdef HAS_X11
#include <X11/Xlib.h>
#include <X11/XKBlib.h>
#include <X11/extensions/record.h>
#include <X11/extensions/Xfixes.h>
#include <X11/extensions/shape.h>
#include <X11/Xatom.h>
#define X11_KEY_PRESS 2
#define X11_KEY_RELEASE 3
#undef KeyPress
#undef KeyRelease
#undef None
#undef Bool
#undef True
#undef False
#undef FocusIn
#undef FocusOut
#undef Status
#include <xcb/xcb.h>
#include <xcb/xinput.h>
#endif

static const QHash<int, QString> &evdevKeyNames()
{
    static const QHash<int, QString> map = {
        {1, "Esc"}, {2, "1"}, {3, "2"}, {4, "3"}, {5, "4"},
        {6, "5"}, {7, "6"}, {8, "7"}, {9, "8"}, {10, "9"},
        {11, "0"}, {12, "-"}, {13, "="}, {14, "Bksp"},
        {15, "Tab"},
        {16, "Q"}, {17, "W"}, {18, "E"}, {19, "R"}, {20, "T"},
        {21, "Y"}, {22, "U"}, {23, "I"}, {24, "O"}, {25, "P"},
        {26, "["}, {27, "]"}, {28, "Enter"}, {29, "Ctrl"},
        {30, "A"}, {31, "S"}, {32, "D"}, {33, "F"}, {34, "G"},
        {35, "H"}, {36, "J"}, {37, "K"}, {38, "L"},
        {39, ";"}, {40, "'"}, {41, "`"}, {42, "Shift"},
        {43, "\\"}, {44, "Z"}, {45, "X"}, {46, "C"}, {47, "V"},
        {48, "B"}, {49, "N"}, {50, "M"},
        {51, ","}, {52, "."}, {53, "/"}, {54, "Shift"},
        {55, "*"}, {56, "Alt"}, {57, "Space"}, {58, "Caps"},
        {59, "F1"}, {60, "F2"}, {61, "F3"}, {62, "F4"},
        {63, "F5"}, {64, "F6"}, {65, "F7"}, {66, "F8"},
        {67, "F9"}, {68, "F10"}, {69, "Num"}, {70, "Scrl"},
        {71, "7"}, {72, "8"}, {73, "9"}, {74, "-"},
        {75, "4"}, {76, "5"}, {77, "6"}, {78, "+"},
        {79, "1"}, {80, "2"}, {81, "3"}, {82, "0"},
        {83, "."}, {96, "Enter"}, {97, "Ctrl"},
        {98, "/"}, {99, "PrtSc"}, {100, "Alt"},
        {102, "Home"}, {103, "\u2191"}, {104, "PgUp"},
        {105, "\u2190"}, {106, "\u2192"}, {107, "End"},
        {108, "\u2193"}, {109, "PgDn"}, {110, "Ins"},
        {111, "Del"}, {119, "Pause"},
        {125, "Win"}, {126, "Win"},
        {127, "Menu"}, {139, "Menu"},
        {87, "F11"}, {88, "F12"},
        {113, "Mute"}, {114, "VolDn"}, {115, "VolUp"},
    };
    return map;
}

Backend::Backend(QObject *parent)
    : QObject(parent)
{
    m_statsTimer = new QTimer(this);
    connect(m_statsTimer, &QTimer::timeout, this, [this]() {
        updateKpm();
        updateCpm();
    });
    m_statsTimer->start(1000);

    initX11GlobalCapture();
    initEvdevCapture();
}

Backend::~Backend()
{
    cleanupEvdevCapture();
#ifdef HAS_X11
    cleanupRecordCapture();
    if (m_xcbConn)
        xcb_disconnect(static_cast<xcb_connection_t *>(m_xcbConn));
    if (m_x11Display)
        XCloseDisplay(static_cast<Display *>(m_x11Display));
#endif
}

void Backend::initX11GlobalCapture()
{
#ifdef HAS_X11
    auto *dpy = XOpenDisplay(nullptr);
    m_x11Display = dpy;
    if (!dpy) {
        qWarning("XOpenDisplay failed - no global capture");
        return;
    }
    qWarning() << "X11 global capture initialized, display" << dpy;

    initX11KeyNames();
    initXCBXI2();

    if (!m_xcbConn) {
        qWarning("XCB init failed - XI2 events unavailable, using XQueryKeymap only");
    }

    m_pollTimer = new QTimer(this);
    connect(m_pollTimer, &QTimer::timeout, this, &Backend::pollX11Events);
    m_pollTimer->start(10);
    initRecordCapture();
#else
    qWarning("HAS_X11 not defined - no global capture");
#endif
}

#ifdef HAS_X11
void Backend::initX11KeyNames()
{
    auto *dpy = static_cast<Display *>(m_x11Display);
    if (!dpy) return;

    int min, max, symsPer;
    XDisplayKeycodes(dpy, &min, &max);
    KeySym *syms = XGetKeyboardMapping(dpy, min, max - min + 1, &symsPer);
    if (!syms) return;

    int mapped = 0;
    for (int kc = min; kc <= max; kc++) {
        int idx = (kc - min) * symsPer;
        KeySym ks = syms[idx];
        if (ks != NoSymbol) {
            char *name = XKeysymToString(ks);
            if (name) {
                m_x11KeyNames[kc] = normalizeKeyName(QString::fromLatin1(name));
                mapped++;
            }
        }
    }
    XFree(syms);
    qWarning() << "Mapped" << mapped << "keycodes from" << min << "to" << max;
}

void Backend::initXCBXI2()
{
    auto *conn = xcb_connect(nullptr, nullptr);
    m_xcbConn = conn;
    if (xcb_connection_has_error(conn)) {
        m_xcbConn = nullptr;
        return;
    }

    auto verCookie = xcb_input_xi_query_version(conn, 2, 4);
    auto *verReply = xcb_input_xi_query_version_reply(conn, verCookie, nullptr);
    if (!verReply) {
        qWarning("XI2 query version failed");
        xcb_disconnect(conn);
        m_xcbConn = nullptr;
        return;
    }
    qWarning() << "XI2 version:" << verReply->major_version << "." << verReply->minor_version;
    free(verReply);

    auto *ext = xcb_get_extension_data(conn, &xcb_input_id);
    if (!ext) {
        xcb_disconnect(conn);
        m_xcbConn = nullptr;
        return;
    }
    m_xiOpcode = ext->major_opcode;

    const auto *setup = xcb_get_setup(conn);
    auto *screen = xcb_setup_roots_iterator(setup).data;
    if (!screen) {
        xcb_disconnect(conn);
        m_xcbConn = nullptr;
        return;
    }

    uint32_t xiMask = XCB_INPUT_XI_EVENT_MASK_KEY_PRESS
                    | XCB_INPUT_XI_EVENT_MASK_KEY_RELEASE
                    | XCB_INPUT_XI_EVENT_MASK_BUTTON_PRESS
                    | XCB_INPUT_XI_EVENT_MASK_BUTTON_RELEASE
                    | XCB_INPUT_XI_EVENT_MASK_MOTION
                    | XCB_INPUT_XI_EVENT_MASK_RAW_MOTION
                    | XCB_INPUT_XI_EVENT_MASK_RAW_BUTTON_PRESS
                    | XCB_INPUT_XI_EVENT_MASK_RAW_BUTTON_RELEASE;

    struct {
        xcb_input_event_mask_t header;
        uint32_t mask;
    } eventMask = {
        { XCB_INPUT_DEVICE_ALL_MASTER, 1 },
        xiMask
    };

    auto cookie = xcb_input_xi_select_events_checked(
        conn, screen->root, 1,
        reinterpret_cast<xcb_input_event_mask_t *>(&eventMask));
    auto *err = xcb_request_check(conn, cookie);
    if (err) {
        free(err);
        xcb_disconnect(conn);
        m_xcbConn = nullptr;
        return;
    }
    xcb_flush(conn);
}

void Backend::processXCBEvents()
{
    auto *conn = static_cast<xcb_connection_t *>(m_xcbConn);
    if (!conn) return;

    xcb_generic_event_t *ev;
    while ((ev = xcb_poll_for_event(conn))) {
        uint8_t type = ev->response_type & ~0x80;
        if (type == m_xiOpcode + XCB_INPUT_MOTION) {
            auto *motion = reinterpret_cast<xcb_input_motion_event_t *>(ev);
            if (m_mouseX != motion->root_x || m_mouseY != motion->root_y) {
                m_mouseX = motion->root_x;
                m_mouseY = motion->root_y;
                emit mouseMoved();
            }
        } else if (type == m_xiOpcode + XCB_INPUT_BUTTON_PRESS
                   || type == m_xiOpcode + XCB_INPUT_RAW_BUTTON_PRESS) {
            auto *bp = reinterpret_cast<xcb_input_button_press_event_t *>(ev);
            if (bp->detail == 4 || bp->detail == 5) {
                m_scrollDirection = bp->detail == 4 ? 1 : -1;
                if (!m_scrolling) {
                    m_scrolling = true;
                    emit scrollChanged();
                }
                QTimer::singleShot(200, this, [this]() {
                    m_scrolling = false;
                    m_scrollDirection = 0;
                    emit scrollChanged();
                });
            }
        }
        free(ev);
    }
}

void Backend::pollX11Events()
{
    auto *dpy = static_cast<Display *>(m_x11Display);

    processXCBEvents();

    char keys[32] = {};
    XQueryKeymap(dpy, keys);

    for (int i = 0; i < 256; i++) {
        bool now = (keys[i >> 3] >> (i & 7)) & 1;
        bool prev = (m_prevKeyState[i >> 3] >> (i & 7)) & 1;
        if (now != prev) {
            auto it = m_x11KeyNames.find(i);
            if (it != m_x11KeyNames.end()) {
                QString name = it.value();
                bool alreadyInState = m_pressedKeys.contains(name);
                if (now && !alreadyInState)
                    processKey(name, true);
                else if (!now && alreadyInState)
                    processKey(name, false);
            }
        }
    }
    memcpy(m_prevKeyState, keys, 32);

    {
        Window root, child;
        int rootX, rootY, winX, winY;
        unsigned int mask;
        if (XQueryPointer(dpy, DefaultRootWindow(dpy), &root, &child,
                          &rootX, &rootY, &winX, &winY, &mask))
        {
            bool changed = false;
            if (m_mouseX != rootX || m_mouseY != rootY) {
                m_mouseX = rootX;
                m_mouseY = rootY;
                emit mouseMoved();
            }
            bool lb = (mask & Button1Mask) != 0;
            bool rb = (mask & Button3Mask) != 0;
            bool mb = (mask & Button2Mask) != 0;
            if (lb != m_leftButton) { m_leftButton = lb; if (lb) { m_totalClicks++; m_clickTimes.append(QDateTime::currentMSecsSinceEpoch()); } changed = true; }
            if (rb != m_rightButton) { m_rightButton = rb; if (rb) { m_totalClicks++; m_clickTimes.append(QDateTime::currentMSecsSinceEpoch()); } changed = true; }
            if (mb != m_middleButton) { m_middleButton = mb; if (mb) { m_totalClicks++; m_clickTimes.append(QDateTime::currentMSecsSinceEpoch()); } changed = true; }
            if (changed) {
                emit mouseButtonChanged();
                emit statsChanged();
            }
        }
    }
}

void Backend::initEvdevCapture()
{
    QDir dir("/dev/input");
    QStringList filters;
    filters << "event*";
    QStringList entries = dir.entryList(filters);
    qWarning("evdev: found %d event devices in /dev/input", entries.size());

    for (const QString &entry : entries) {
        QString path = dir.filePath(entry);
        int fd = open(path.toLocal8Bit().constData(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) {
            qWarning("evdev: cannot open %s: %s", qPrintable(path), strerror(errno));
            continue;
        }

        unsigned char keyBits[KEY_CNT / 8 + 1] = {};
        int ret = ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(keyBits)), keyBits);
        if (ret < 0) {
            qWarning("evdev: ioctl EVIOCGBIT failed on %s: %s", qPrintable(path), strerror(errno));
            close(fd);
            continue;
        }

        int letters = 0;
        for (int code = KEY_Q; code <= KEY_P; code++)
            if (keyBits[code / 8] & (1 << (code % 8))) letters++;
        for (int code = KEY_A; code <= KEY_L; code++)
            if (keyBits[code / 8] & (1 << (code % 8))) letters++;
        for (int code = KEY_Z; code <= KEY_M; code++)
            if (keyBits[code / 8] & (1 << (code % 8))) letters++;

        qWarning("evdev: scanned %s: ioctl=%d letters=%d", qPrintable(path), ret, letters);

        if (letters >= 5) {
            m_evdevDevices.append(fd);
            qWarning("evdev: added keyboard %s (fd %d, %d letter keys)", qPrintable(path), fd, letters);
        } else {
            close(fd);
        }
    }

    if (m_evdevDevices.isEmpty()) {
        qWarning("evdev: no keyboard devices found");
        qWarning("evdev: try 'sudo usermod -aG input $USER' then logout/login");
    } else {
        qWarning("evdev: monitoring %d keyboard device(s)", m_evdevDevices.size());
    }

    m_evdevTimer = new QTimer(this);
    connect(m_evdevTimer, &QTimer::timeout, this, &Backend::readEvdevEvents);
    m_evdevTimer->start(10);
}

void Backend::readEvdevEvents()
{
    if (m_evdevDevices.isEmpty()) return;

    struct input_event ev;
    for (int fd : m_evdevDevices) {
        while (true) {
            errno = 0;
            ssize_t n = read(fd, &ev, sizeof(ev));
            if (n < 0) {
                if (errno == EAGAIN || errno == EWOULDBLOCK)
                    break;
                continue;
            }
            if (n != sizeof(ev)) continue;
            if (ev.type != EV_KEY) continue;
            if (ev.value == 2) continue;

            const auto &map = evdevKeyNames();
            auto it = map.find(ev.code);
            if (it != map.end()) {
                processKey(it.value(), ev.value == 1);
            }
        }
    }
}

void Backend::cleanupEvdevCapture()
{
    if (m_evdevTimer) {
        m_evdevTimer->stop();
        delete m_evdevTimer;
        m_evdevTimer = nullptr;
    }
    for (int fd : m_evdevDevices)
        close(fd);
    m_evdevDevices.clear();
}

void Backend::handleXI2Button(uint8_t detail, bool pressed)
{
    bool changed = false;
    auto click = [&](bool &field, int btn) {
        if (field != pressed) {
            field = pressed;
            if (pressed && (btn == 1 || btn == 2 || btn == 3)) {
                m_totalClicks++;
                m_clickTimes.append(QDateTime::currentMSecsSinceEpoch());
            }
            changed = true;
        }
    };

    if (detail == 1) click(m_leftButton, 1);
    else if (detail == 2) click(m_middleButton, 2);
    else if (detail == 3) click(m_rightButton, 3);
    else if (detail == 4) { m_scrollDirection = 1; m_scrolling = true; emit scrollChanged(); QTimer::singleShot(200, this, [this](){ m_scrolling = false; m_scrollDirection = 0; emit scrollChanged(); }); }
    else if (detail == 5) { m_scrollDirection = -1; m_scrolling = true; emit scrollChanged(); QTimer::singleShot(200, this, [this](){ m_scrolling = false; m_scrollDirection = 0; emit scrollChanged(); }); }

    if (changed) {
        emit mouseButtonChanged();
        emit statsChanged();
    }
}
void Backend::initRecordCapture()
{
    auto *ctrlDpy = static_cast<Display *>(m_x11Display);
    if (!ctrlDpy) return;

    int ev, err;
    if (!XRecordQueryVersion(ctrlDpy, &ev, &err)) {
        qWarning("XRecord extension not available");
        return;
    }
    qWarning() << "XRecord version:" << ev << "." << err;

    auto *dataDpy = XOpenDisplay(nullptr);
    if (!dataDpy) {
        qWarning("XRecord: failed to open data display");
        return;
    }
    m_recordDataDisplay = dataDpy;

    auto *range = XRecordAllocRange();
    if (!range) {
        qWarning("XRecord: alloc range failed");
        XCloseDisplay(dataDpy);
        m_recordDataDisplay = nullptr;
        return;
    }
    range->device_events.first = X11_KEY_PRESS;
    range->device_events.last = X11_KEY_RELEASE;

    XRecordClientSpec clientSpec = XRecordAllClients;
    XRecordContext ctx = XRecordCreateContext(ctrlDpy, 0, &clientSpec, 1, &range, 1);
    XFree(range);

    if (!ctx) {
        qWarning("XRecord: create context failed");
        XCloseDisplay(dataDpy);
        m_recordDataDisplay = nullptr;
        return;
    }
    m_recordContext = static_cast<unsigned long>(ctx);
    XSync(ctrlDpy, 0);
    if (!XRecordEnableContextAsync(dataDpy, ctx,
                                   [](XPointer closure, XRecordInterceptData *data) {
                                       auto *b = reinterpret_cast<Backend *>(closure);
                                       if (!b || !data) { if (data) XRecordFreeData(data); return; }
                                       if (data->data_len < 2) { XRecordFreeData(data); return; }
                                       uint8_t type = data->data[0];
                                       uint8_t kc = data->data[1];
                                       if (data->category == XRecordFromServer
                                           || data->category == XRecordFromClient) {
                                           if (type == X11_KEY_PRESS || type == X11_KEY_RELEASE) {
                                               auto it = b->m_x11KeyNames.find(kc);
                                               if (it != b->m_x11KeyNames.end())
                                                   b->processKey(it.value(), type == X11_KEY_PRESS);
                                           }
                                       }
                                       XRecordFreeData(data);
                                   },
                                   reinterpret_cast<XPointer>(this)))
    {
        qWarning("XRecord: enable context async failed");
        XRecordFreeContext(ctrlDpy, ctx);
        m_recordContext = 0;
        XCloseDisplay(dataDpy);
        m_recordDataDisplay = nullptr;
        return;
    }

    int fd = XConnectionNumber(dataDpy);
    m_recordNotifier = new QSocketNotifier(fd, QSocketNotifier::Read, this);
    connect(m_recordNotifier, &QSocketNotifier::activated,
            this, &Backend::onRecordDataAvailable);

    auto *flushTimer = new QTimer(this);
    connect(flushTimer, &QTimer::timeout, this, &Backend::onRecordDataAvailable);
    flushTimer->start(30);

    m_recordEnabled = true;
    qWarning("XRecord capture enabled - will capture all keyboard events");
}

void Backend::onRecordDataAvailable()
{
    auto *dataDpy = static_cast<Display *>(m_recordDataDisplay);
    if (dataDpy) {
        XRecordProcessReplies(dataDpy);
    }
}

void Backend::cleanupRecordCapture()
{
    if (!m_recordEnabled) return;

    if (m_recordNotifier) {
        m_recordNotifier->setEnabled(false);
        delete m_recordNotifier;
        m_recordNotifier = nullptr;
    }

    XRecordContext ctx = static_cast<XRecordContext>(m_recordContext);
    auto *ctrlDpy = static_cast<Display *>(m_x11Display);
    auto *dataDpy = static_cast<Display *>(m_recordDataDisplay);

    if (ctrlDpy && ctx) {
        XRecordDisableContext(ctrlDpy, ctx);
        XSync(ctrlDpy, 0);
    }

    if (dataDpy)
        XRecordProcessReplies(dataDpy);

    if (ctrlDpy && ctx)
        XRecordFreeContext(ctrlDpy, ctx);

    if (dataDpy)
        XCloseDisplay(dataDpy);

    m_recordContext = 0;
    m_recordDataDisplay = nullptr;
    m_recordEnabled = false;
    qWarning("XRecord capture disabled");
}
#endif

QString Backend::normalizeKeyName(const QString &raw) const
{
    static const QMap<QString, QString> map = {
        {"Return", "Enter"}, {"BackSpace", "Bksp"}, {"Backspace", "Bksp"},
        {"Escape", "Esc"}, {"space", "Space"},
        {"Control_L", "Ctrl"}, {"Control_R", "Ctrl"},
        {"Shift_L", "Shift"}, {"Shift_R", "Shift"},
        {"Alt_L", "Alt"}, {"Alt_R", "Alt"},
        {"Super_L", "Win"}, {"Super_R", "Win"}, {"Meta_L", "Win"}, {"Meta_R", "Win"},
        {"Caps_Lock", "Caps"}, {"Num_Lock", "Num"}, {"Scroll_Lock", "Scrl"},
        {"KP_Enter", "Enter"}, {"KP_Delete", "Del"},
        {"ISO_Left_Tab", "Tab"}, {"Menu", "Menu"},
        {"Page_Up", "PgUp"}, {"Page_Down", "PgDn"},
        {"Prior", "PgUp"}, {"Next", "PgDn"},
    };

    auto it = map.find(raw);
    if (it != map.end())
        return it.value();

    if (raw.length() == 1) {
        QChar c = raw[0];
        if (c.isLower() || c.isUpper())
            return QString(c.toUpper());
        return raw;
    }

    return raw;
}

void Backend::processKey(const QString &key, bool pressed)
{
    if (pressed) {
        if (m_pressedKeys.contains(key)) return;
        m_pressedKeys.insert(key);
        m_lastKey = key;
        qWarning("KEY: %s", qPrintable(key));
        m_times.append(QDateTime::currentMSecsSinceEpoch());
        m_totalKeys++;
        m_keyCounts[key]++;
        m_recentKeys.prepend(key);
        while (m_recentKeys.size() > 12)
            m_recentKeys.removeLast();
        emit lastKeyChanged();
        emit recentKeysChanged();
        emit statsChanged();

        if (key == "V" && m_pressedKeys.contains("Ctrl") && m_pressedKeys.contains("Shift"))
            emit toggleOverlay();
        if (key == "C" && m_pressedKeys.contains("Ctrl") && m_pressedKeys.contains("Shift"))
            setClickThrough(!m_clickThrough);
    } else {
        if (!m_pressedKeys.contains(key)) return;
        m_pressedKeys.remove(key);
    }
    emit keyChanged(key, pressed);
}

void Backend::registerKey(const QString &key)
{
    processKey(key, true);
    QTimer::singleShot(250, this, [this, key]() {
        processKey(key, false);
    });
}

bool Backend::isKeyPressed(const QString &key) const
{
    return m_pressedKeys.contains(key);
}

void Backend::updateKpm()
{
    qint64 now = QDateTime::currentMSecsSinceEpoch();
    while (!m_times.isEmpty() && m_times.first() < now - 60000)
        m_times.removeFirst();
    m_kpm = m_times.size();
    emit statsChanged();
}

void Backend::updateCpm()
{
    qint64 now = QDateTime::currentMSecsSinceEpoch();
    while (!m_clickTimes.isEmpty() && m_clickTimes.first() < now - 60000)
        m_clickTimes.removeFirst();
    m_cpm = m_clickTimes.size();
}

QString Backend::topKey() const
{
    if (m_keyCounts.isEmpty()) return QStringLiteral("\u2014");
    auto it = std::max_element(m_keyCounts.begin(), m_keyCounts.end(),
        [](int a, int b) { return a < b; });
    return it.key();
}

bool Backend::eventFilter(QObject *obj, QEvent *event)
{
    switch (event->type()) {
    case QEvent::KeyPress: {
        auto *ke = static_cast<QKeyEvent *>(event);
        if (!ke->isAutoRepeat())
            processKey(keyEventToString(ke), true);
        break;
    }
    case QEvent::KeyRelease: {
        auto *ke = static_cast<QKeyEvent *>(event);
        if (!ke->isAutoRepeat())
            processKey(keyEventToString(ke), false);
        break;
    }
    case QEvent::MouseMove: {
        auto *me = static_cast<QMouseEvent *>(event);
        m_mouseX = static_cast<int>(me->globalPosition().x());
        m_mouseY = static_cast<int>(me->globalPosition().y());
        emit mouseMoved();
        break;
    }
    case QEvent::MouseButtonPress: {
        auto *me = static_cast<QMouseEvent *>(event);
        updateMouseButton(me->button(), true);
        break;
    }
    case QEvent::MouseButtonRelease: {
        auto *me = static_cast<QMouseEvent *>(event);
        updateMouseButton(me->button(), false);
        break;
    }
    case QEvent::Wheel: {
        auto *we = static_cast<QWheelEvent *>(event);
        m_scrollDirection = we->angleDelta().y() > 0 ? 1 : -1;
        m_scrolling = true;
        emit scrollChanged();
        QTimer::singleShot(200, this, [this]() {
            m_scrolling = false;
            m_scrollDirection = 0;
            emit scrollChanged();
        });
        break;
    }
    default:
        break;
    }
    return QObject::eventFilter(obj, event);
}

QString Backend::keyEventToString(QKeyEvent *ke) const
{
    int key = ke->key();

    if (key >= Qt::Key_A && key <= Qt::Key_Z)
        return QChar(key);

    if (key >= Qt::Key_0 && key <= Qt::Key_9)
        return QChar(key);

    if (key >= Qt::Key_F1 && key <= Qt::Key_F12) {
        int n = key - Qt::Key_F1 + 1;
        return QString("F%1").arg(n);
    }

    static const QMap<int, QString> special = {
        {Qt::Key_Return, "Enter"}, {Qt::Key_Enter, "Enter"},
        {Qt::Key_Tab, "Tab"}, {Qt::Key_Backspace, "Bksp"},
        {Qt::Key_Escape, "Esc"}, {Qt::Key_Space, "Space"},
        {Qt::Key_Shift, "Shift"}, {Qt::Key_Control, "Ctrl"},
        {Qt::Key_Alt, "Alt"}, {Qt::Key_Meta, "Win"},
        {Qt::Key_Super_L, "Win"}, {Qt::Key_Super_R, "Win"},
        {Qt::Key_CapsLock, "Caps"}, {Qt::Key_Delete, "Del"},
        {Qt::Key_Insert, "Ins"}, {Qt::Key_Home, "Home"},
        {Qt::Key_End, "End"}, {Qt::Key_PageUp, "PgUp"},
        {Qt::Key_PageDown, "PgDn"}, {Qt::Key_Menu, "Menu"},
        {Qt::Key_Up, "\u2191"}, {Qt::Key_Down, "\u2193"},
        {Qt::Key_Left, "\u2190"}, {Qt::Key_Right, "\u2192"},
        {Qt::Key_Backslash, "\\"}, {Qt::Key_Slash, "/"},
        {Qt::Key_Period, "."}, {Qt::Key_Comma, ","},
        {Qt::Key_Semicolon, ";"}, {Qt::Key_Apostrophe, "'"},
        {Qt::Key_BracketLeft, "["}, {Qt::Key_BracketRight, "]"},
        {Qt::Key_Minus, "-"}, {Qt::Key_Equal, "="},
        {Qt::Key_QuoteLeft, "`"},
    };

    auto it = special.find(key);
    if (it != special.end())
        return it.value();

    return QKeySequence(key).toString();
}

void Backend::setupX11Overlay(QObject *win)
{
#ifdef HAS_X11
    m_overlayQWindow = qobject_cast<QQuickWindow *>(win);
    if (!m_overlayQWindow) {
        qWarning("X11 overlay: not a QQuickWindow");
        return;
    }
    initX11Overlay();
    connect(m_overlayQWindow, &QWindow::visibleChanged, this, [this]() {
        initX11Overlay();
    });
#endif
}

void Backend::setupPopupOverlay(QObject *win)
{
#ifdef HAS_X11
    auto *qw = qobject_cast<QQuickWindow *>(win);
    if (!qw || !m_x11Display) return;
    auto *dpy = static_cast<Display *>(m_x11Display);
    ::Window wid = static_cast<::Window>(qw->winId());
    if (wid) {
        XRectangle empty = {0, 0, 0, 0};
        XShapeCombineRectangles(dpy, wid, ShapeInput, 0, 0,
                                &empty, 1, ShapeSet, YXBanded);
        XSync(dpy, 0);
    }
    connect(qw, &QWindow::visibleChanged, this, [qw, dpy]() {
        ::Window wid = static_cast<::Window>(qw->winId());
        if (wid) {
            XRectangle empty = {0, 0, 0, 0};
            XShapeCombineRectangles(dpy, wid, ShapeInput, 0, 0,
                                    &empty, 1, ShapeSet, YXBanded);
            XSync(dpy, 0);
        }
    });
#endif
}

void Backend::initX11Overlay()
{
#ifdef HAS_X11
    auto *dpy = static_cast<Display *>(m_x11Display);
    if (!dpy || !m_overlayQWindow) return;

    ::Window wid = static_cast<::Window>(m_overlayQWindow->winId());
    if (!wid) {
        qWarning("X11 overlay: no native window yet");
        return;
    }
    m_overlayWindow = wid;

    Atom netWmType = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE", 0);
    Atom normalType = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE_NORMAL", 0);
    XChangeProperty(dpy, wid, netWmType, XA_ATOM, 32,
                    PropModeReplace, (unsigned char *)&normalType, 1);

    Atom netWmState = XInternAtom(dpy, "_NET_WM_STATE", 0);
    Atom above    = XInternAtom(dpy, "_NET_WM_STATE_ABOVE", 0);
    Atom sticky   = XInternAtom(dpy, "_NET_WM_STATE_STICKY", 0);
    Atom skipBar  = XInternAtom(dpy, "_NET_WM_STATE_SKIP_TASKBAR", 0);
    Atom skipPgr  = XInternAtom(dpy, "_NET_WM_STATE_SKIP_PAGER", 0);
    Atom states[] = { above, sticky, skipBar, skipPgr };
    XChangeProperty(dpy, wid, netWmState, XA_ATOM, 32,
                    PropModeReplace, (unsigned char *)states, 4);

    XSync(dpy, 0);

    int evBase, errBase;
    if (!XFixesQueryExtension(dpy, &evBase, &errBase)) {
        qWarning("X11 overlay: XFixes not available");
        return;
    }

    applyClickThrough(m_clickThrough);
    applyAlphaBackground(m_alphaBackground);

    qWarning("X11 overlay: dock type set + click-through=%s",
             m_clickThrough ? "ON" : "OFF");
#endif
}

int Backend::addExcludeRect(int x, int y, int w, int h)
{
    int id = ++m_rectIdCounter;
    m_excludeRects[id] = QRect(x, y, w, h);
    return id;
}

void Backend::removeExcludeRect(int id)
{
    m_excludeRects.remove(id);
}

void Backend::clearExcludeRects()
{
    m_excludeRects.clear();
}

void Backend::applyClickThrough(bool enable)
{
#ifdef HAS_X11
    if (!m_x11Display || !m_overlayWindow) return;
    auto *dpy = static_cast<Display *>(m_x11Display);
    ::Window wid = static_cast<::Window>(m_overlayWindow);

    if (enable) {
        XRectangle empty = {0, 0, 0, 0};
        XShapeCombineRectangles(dpy, wid, ShapeInput, 0, 0,
                                &empty, 1, ShapeSet, YXBanded);

        for (auto it = m_excludeRects.constBegin(); it != m_excludeRects.constEnd(); ++it) {
            const QRect &r = it.value();
            if (r.width() <= 0 || r.height() <= 0) continue;
            XRectangle xr = {
                static_cast<short>(r.x()),
                static_cast<short>(r.y()),
                static_cast<unsigned short>(r.width()),
                static_cast<unsigned short>(r.height())
            };
            XShapeCombineRectangles(dpy, wid, ShapeInput, 0, 0,
                                    &xr, 1, ShapeUnion, YXBanded);
        }
    } else {
        XWindowAttributes attrs;
        if (!XGetWindowAttributes(dpy, wid, &attrs)) return;
        XRectangle fullRect = {0, 0,
            static_cast<unsigned short>(attrs.width),
            static_cast<unsigned short>(attrs.height)};
        XShapeCombineRectangles(dpy, wid, ShapeInput, 0, 0,
                                &fullRect, 1, ShapeSet, YXBanded);
    }
    XSync(dpy, 0);
    qWarning("X11 overlay: click-through %s (rects=%d)", enable ? "ON" : "OFF", m_excludeRects.size());
#endif
}

void Backend::applyAlphaBackground(bool enable)
{
#ifdef HAS_X11
    if (!m_x11Display || !m_overlayWindow) return;
    auto *dpy = static_cast<Display *>(m_x11Display);
    ::Window wid = static_cast<::Window>(m_overlayWindow);

    XWindowAttributes attrs;
    if (XGetWindowAttributes(dpy, wid, &attrs) && attrs.depth == 32) {
        XSetWindowBackgroundPixmap(dpy, wid, 0);
        XClearWindow(dpy, wid);
    }
    XSync(dpy, 0);
#endif
}

void Backend::setClickThrough(bool enable)
{
    if (m_clickThrough == enable) return;
    m_clickThrough = enable;
    applyClickThrough(enable);
    emit clickThroughChanged();
}

void Backend::setAlphaBackground(bool enable)
{
    if (m_alphaBackground == enable) return;
    m_alphaBackground = enable;
    applyAlphaBackground(enable);
    emit alphaBackgroundChanged();
}

void Backend::updateMouseButton(Qt::MouseButton button, bool pressed)
{
    bool changed = false;
    auto click = [&](bool &field) {
        if (field != pressed) {
            field = pressed;
            if (pressed) {
                m_totalClicks++;
                m_clickTimes.append(QDateTime::currentMSecsSinceEpoch());
            }
            changed = true;
        }
    };

    switch (button) {
    case Qt::LeftButton: click(m_leftButton); break;
    case Qt::RightButton: click(m_rightButton); break;
    case Qt::MiddleButton: click(m_middleButton); break;
    default: return;
    }

    if (changed) {
        emit mouseButtonChanged();
        emit statsChanged();
    }
}
