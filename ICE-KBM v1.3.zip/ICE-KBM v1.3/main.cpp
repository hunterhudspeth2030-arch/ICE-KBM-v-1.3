#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>
#include <QSurfaceFormat>
#include "backend.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QSurfaceFormat fmt;
    fmt.setAlphaBufferSize(8);
    QSurfaceFormat::setDefaultFormat(fmt);

    Backend backend;
    app.installEventFilter(&backend);

    QQmlApplicationEngine engine;

    QObject::connect(&engine, &QQmlApplicationEngine::warnings,
        [](const QList<QQmlError> &warnings) {
            for (const auto &w : warnings)
                qWarning().noquote() << w.toString();
        });

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &engine, []() {
            qCritical("Failed to load QML - window won't appear");
        });

    engine.rootContext()->setContextProperty("backend", &backend);

    engine.loadFromModule("CatchyOS", "Main");

    for (auto *obj : engine.rootObjects()) {
        if (auto *win = qobject_cast<QQuickWindow *>(obj)) {
            backend.setupX11Overlay(win);
            break;
        }
    }

    return app.exec();
}
